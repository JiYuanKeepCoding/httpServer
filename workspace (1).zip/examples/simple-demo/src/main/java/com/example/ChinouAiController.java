package com.example;

import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller for interacting with the Chinou AI model.
 */
@RestController
@RequestMapping("/api/chinou")
public class ChinouAiController {

    private final ChatClient chinouAiChatClient;

    @Autowired
    public ChinouAiController(ChatClient chinouAiChatClient) {
        this.chinouAiChatClient = chinouAiChatClient;
    }

    /**
     * Simple endpoint to get a completion from Chinou AI.
     *
     * @param prompt The prompt text to send to the model
     * @return Response from the model
     */
    @GetMapping("/chat")
    public Map<String, String> chat(@RequestParam String prompt) {
        Prompt aiPrompt = new Prompt(new UserMessage(prompt));
        ChatResponse response = chinouAiChatClient.call(aiPrompt);
        
        Map<String, String> result = new HashMap<>();
        result.put("prompt", prompt);
        result.put("response", response.getResults().get(0).getOutput().getContent());
        return result;
    }

    /**
     * Endpoint for getting a completion with custom options.
     */
    @PostMapping("/chat-with-options")
    public Map<String, String> chatWithOptions(@RequestBody ChatRequest chatRequest) {
        Prompt aiPrompt = new Prompt(new UserMessage(chatRequest.getPrompt()));
        
        Map<String, Object> options = new HashMap<>();
        if (chatRequest.getTemperature() != null) {
            options.put("temperature", chatRequest.getTemperature());
        }
        if (chatRequest.getMaxTokens() != null) {
            options.put("maxTokens", chatRequest.getMaxTokens());
        }
        
        ChatResponse response = chinouAiChatClient.call(aiPrompt, options);
        
        Map<String, String> result = new HashMap<>();
        result.put("prompt", chatRequest.getPrompt());
        result.put("response", response.getResults().get(0).getOutput().getContent());
        return result;
    }

    /**
     * Request class for the chat-with-options endpoint.
     */
    public static class ChatRequest {
        private String prompt;
        private Float temperature;
        private Integer maxTokens;

        public String getPrompt() {
            return prompt;
        }

        public void setPrompt(String prompt) {
            this.prompt = prompt;
        }

        public Float getTemperature() {
            return temperature;
        }

        public void setTemperature(Float temperature) {
            this.temperature = temperature;
        }

        public Integer getMaxTokens() {
            return maxTokens;
        }

        public void setMaxTokens(Integer maxTokens) {
            this.maxTokens = maxTokens;
        }
    }
}