package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Demo application showing how to use the Chinou AI extension with Spring AI.
 */
@SpringBootApplication
public class ChinouAiDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChinouAiDemoApplication.class, args);
    }
}