# Spring AI Chinou Extension

This library provides an extension for Spring AI to integrate with an internal LLM API called `chinou.com/invoke`. The extension
supports Basic Authentication and can be easily configured through YAML properties in a Spring Boot application.

## Features

- Seamless integration with the Chinou API
- Support for Basic Authentication (username/password)
- Configurable API parameters (temperature, max tokens, etc.)
- Retry mechanism for handling transient errors
- Compatible with Spring AI abstractions (ChatClient, etc.)

## Getting Started

### Add Maven Dependency

```xml
<dependency>
    <groupId>com.chinou</groupId>
    <artifactId>spring-ai-chinou-extension</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

### Configuration

Add the following configuration to your `application.yml` or `application.properties` file:

```yaml
spring:
  ai:
    chinou:
      enabled: true
      base-url: https://chinou.com
      username: ${CHINOU_API_USERNAME}
      password: ${CHINOU_API_PASSWORD}
      model: your-model-name  # Optional, defaults to 'default'
      options:
        temperature: 0.7      # Optional
        max-tokens: 2048      # Optional
        top-k: 40            # Optional
        top-p: 0.95          # Optional
```

### Usage Example

```java
@Service
public class MyAiService {

    private final ChatClient chatClient;

    public MyAiService(ChatClient chatClient) {
        this.chatClient = chatClient;
    }

    public String generateResponse(String userInput) {
        Prompt prompt = new Prompt(new UserMessage(userInput));
        ChatResponse response = chatClient.call(prompt);
        return response.getResults().get(0).getOutput().getContent();
    }
}
```

## Advanced Usage

### Custom Options

You can pass custom options for individual requests:

```java
Map<String, Object> options = Map.of(
        "temperature", 0.3f,
        "maxTokens", 500
);
Prompt prompt = new Prompt(new UserMessage("Tell me a short story"));
ChatResponse response = chatClient.call(prompt, options);
```

### Multiple Messages

You can pass a sequence of messages to create a conversation:

```java
List<Message> messages = List.of(
        new SystemMessage("You are a helpful AI assistant"),
        new UserMessage("What is Spring AI?"),
        new AssistantMessage("Spring AI is a framework for AI integration in Spring applications."),
        new UserMessage("How can I integrate my internal model?")
);

Prompt prompt = new Prompt(messages);
ChatResponse response = chatClient.call(prompt);
```

## Building from Source

To build the project from source:

```bash
./mvnw clean install
```

## License

This project is licensed under the [Apache License 2.0](LICENSE).
