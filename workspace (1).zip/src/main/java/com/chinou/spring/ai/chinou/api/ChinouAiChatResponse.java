package com.chinou.spring.ai.chinou.api;

import org.springframework.ai.chat.messages.AssistantMessage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Response object for Chinou AI API chat completion requests.
 * This class maps to the response format of the Chinou internal API.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChinouAiChatResponse {

    /**
     * The LLM document response data.
     */
    @JsonProperty("LLMDocuResponse")
    private LLMDocuResponse llmDocuResponse;
    
    /**
     * Protocol information.
     */
    @JsonProperty("_protocol")
    private String protocol;
    
    /**
     * Accessor method to get the message in Spring AI's format.
     */
    public AssistantMessage getMessage() {
        if (llmDocuResponse != null && llmDocuResponse.getBody() != null) {
            return new AssistantMessage(llmDocuResponse.getBody());
        }
        return new AssistantMessage("");
    }
    
    /**
     * Get the server information used for generation.
     */
    public String getModel() {
        if (llmDocuResponse != null && llmDocuResponse.getParameters() != null) {
            return llmDocuResponse.getParameters().getServer();
        }
        return "unknown";
    }
    
    /**
     * Inner class representing the LLMDocuResponse portion of the API response.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LLMDocuResponse {
        
        /**
         * The response text from the model.
         */
        @JsonProperty("body")
        private String body;
        
        /**
         * Metrics about the response generation.
         */
        @JsonProperty("metrics")
        private Metrics metrics;
        
        /**
         * Parameters about the response.
         */
        @JsonProperty("parameters")
        private Parameters parameters;
        
        /**
         * Document set for RAG responses.
         */
        @JsonProperty("LLMDocumentSet")
        private LLMDocumentSet llmDocumentSet;
    }
    
    /**
     * Metrics about the response generation.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Metrics {
        
        /**
         * The time the request was invoked.
         */
        @JsonProperty("invoke_time")
        private String invokeTime;
        
        /**
         * Execution time in milliseconds.
         */
        @JsonProperty("execution_time_ms")
        private Double executionTimeMs;
        
        /**
         * Length of the prompt in tokens.
         */
        @JsonProperty("prompt_len")
        private Integer promptLen;
        
        /**
         * Length of the response in tokens.
         */
        @JsonProperty("response_len")
        private Integer responseLen;
    }
    
    /**
     * Parameters about the response.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Parameters {
        
        /**
         * Server information.
         */
        @JsonProperty("server")
        private String server;
    }
    
    /**
     * Document set for RAG responses.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LLMDocumentSet {
        
        /**
         * List of documents used in RAG responses.
         */
        @JsonProperty("documents")
        private List<Object> documents;
    }
}