package com.chinou.spring.ai.chinou.api;

import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.Generation;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.SystemPromptTemplate;
import org.springframework.ai.chat.prompt.UserPromptTemplate;
import org.springframework.ai.model.ModelOptionsUtils;
import org.springframework.ai.retry.RetryUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.Assert;
import org.springframework.util.MimeType;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Interface defining the API for Chinou AI interactions. 
 * This interface serves as a wrapper around the core functionality needed to interact with the Chinou AI API.
 */
public interface ChinouAiApi {

    /**
     * Sends a completion request to the Chinou API.
     * 
     * @param prompt The prompt to send to the API
     * @param options Optional configuration options for the request
     * @return Response from the Chinou API
     */
    ChinouAiChatResponse chatCompletion(String prompt, @Nullable Map<String, Object> options);
    
    /**
     * Sends a completion request with messages to the Chinou API.
     * 
     * @param messages List of messages to send to the API
     * @param options Optional configuration options for the request
     * @return Response from the Chinou API
     */
    ChinouAiChatResponse chatCompletion(List<Message> messages, @Nullable Map<String, Object> options);
}