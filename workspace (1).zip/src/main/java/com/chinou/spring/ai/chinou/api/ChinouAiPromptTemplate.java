package com.chinou.spring.ai.chinou.api;

import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.prompt.PromptsException;
import org.springframework.ai.prompt.SystemPromptTemplate;
import org.springframework.ai.prompt.messages.MessageUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Template for creating prompts for the Chinou AI API.
 */
public class ChinouAiPromptTemplate {

    private final String template;
    private final Map<String, Object> defaultParameters;

    /**
     * Create a new ChinouAiPromptTemplate with the given template and default parameters.
     *
     * @param template the template string
     * @param defaultParameters default parameters for the template
     */
    public ChinouAiPromptTemplate(String template, Map<String, Object> defaultParameters) {
        this.template = template;
        this.defaultParameters = new HashMap<>(defaultParameters);
    }

    /**
     * Create a new ChinouAiPromptTemplate with the given template.
     *
     * @param template the template string
     */
    public ChinouAiPromptTemplate(String template) {
        this(template, Map.of());
    }

    /**
     * Create a system message from the template with the given parameters.
     * 
     * @param parameters the parameters to apply to the template
     * @return a system message with the rendered template
     * @throws PromptsException if an error occurs while rendering the template
     */
    public Message createSystemMessage(Map<String, Object> parameters) {
        Map<String, Object> allParameters = new HashMap<>(defaultParameters);
        allParameters.putAll(parameters);
        
        try {
            SystemPromptTemplate systemPromptTemplate = new SystemPromptTemplate(template);
            return systemPromptTemplate.createMessage(allParameters);
        }
        catch (Exception e) {
            throw new PromptsException("Error creating system message from template: " + e.getMessage(), e);
        }
    }

    /**
     * Create a system message from the template with the default parameters.
     * 
     * @return a system message with the rendered template
     * @throws PromptsException if an error occurs while rendering the template
     */
    public Message createSystemMessage() {
        return createSystemMessage(Map.of());
    }
}