package com.chinou.spring.ai.chinou.api;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.NestedConfigurationProperty;
import org.springframework.util.Assert;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * Configuration properties for the Chinou AI API.
 */
@Data
@ConfigurationProperties(prefix = "spring.ai.chinou")
public class ChinouAiProperties {

    /**
     * Base URL for the Chinou AI API.
     */
    @NotEmpty
    private String baseUrl = "https://chinou.com";
    
    /**
     * Username for Basic authentication.
     */
    private String username;
    
    /**
     * Password for Basic authentication.
     */
    private String password;

    /**
     * The model to use for API calls.
     */
    private String model = "default";

    /**
     * Options for API requests.
     */
    @NestedConfigurationProperty
    private Options options = new Options();

    /**
     * Default retry configuration for API calls.
     */
    @NestedConfigurationProperty
    private Retry retry = new Retry();

    /**
     * Validate the properties.
     */
    public void validate() {
        Assert.hasText(this.baseUrl, "Base URL is required");
        if (this.username != null || this.password != null) {
            Assert.hasText(this.username, "Username is required when password is provided");
            Assert.hasText(this.password, "Password is required when username is provided");
        }
    }

    /**
     * Options for API requests.
     */
    @Data
    public static class Options {
        
        /**
         * Controls the randomness of the output.
         * Range: 0.0 - 2.0
         */
        private Float temperature = 0.7f;

        /**
         * Limits the number of tokens to generate in the response.
         */
        private Integer maxTokens = 2048;

        /**
         * Considers only the top k most likely tokens at each step.
         */
        private Integer topK = 40;

        /**
         * Samples from the top tokens whose probabilities add up to top_p.
         * Range: 0.0 - 1.0
         */
        private Float topP = 0.95f;
    }

    /**
     * Retry configuration for API calls.
     */
    @Data
    public static class Retry {
        
        /**
         * Maximum number of retry attempts.
         */
        private Integer maxAttempts = 3;
        
        /**
         * Initial backoff interval in milliseconds.
         */
        private Long backoffInitialInterval = 2000L;
        
        /**
         * Maximum backoff interval in milliseconds.
         */
        private Long backoffMaxInterval = 10000L;
        
        /**
         * Backoff multiplier.
         */
        private Double backoffMultiplier = 2.0;
    }
}