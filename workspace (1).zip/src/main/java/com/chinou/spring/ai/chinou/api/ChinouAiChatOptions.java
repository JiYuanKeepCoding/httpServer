package com.chinou.spring.ai.chinou.api;

import org.springframework.boot.context.properties.NestedConfigurationProperty;

import java.util.Objects;

import lombok.Data;

/**
 * Configuration options for Chinou AI API requests.
 */
@Data
public class ChinouAiChatOptions {

    /**
     * Controls the randomness of the output. Higher values (e.g., 1.0) make the output more random,
     * while lower values (e.g., 0.2) make it more deterministic.
     * Range: 0.0 - 2.0
     */
    private Float temperature;

    /**
     * Limits the number of tokens to generate in the response.
     */
    private Integer maxTokens;

    /**
     * Considers only the top k most likely tokens at each step.
     */
    private Integer topK;

    /**
     * Samples from the top tokens whose probabilities add up to top_p.
     * Range: 0.0 - 1.0
     */
    private Float topP;

    /**
     * Create ChinouAiChatOptions from properties.
     *
     * @param properties the properties
     * @return the ChinouAiChatOptions
     */
    public static ChinouAiChatOptions fromProperties(ChinouAiProperties properties) {
        ChinouAiChatOptions options = new ChinouAiChatOptions();
        options.setTemperature(properties.getOptions().getTemperature());
        options.setMaxTokens(properties.getOptions().getMaxTokens());
        options.setTopK(properties.getOptions().getTopK());
        options.setTopP(properties.getOptions().getTopP());
        return options;
    }

    /**
     * Builder pattern for creating ChinouAiChatOptions.
     */
    public static class Builder {
        private final ChinouAiChatOptions options = new ChinouAiChatOptions();

        public Builder withTemperature(Float temperature) {
            options.temperature = temperature;
            return this;
        }

        public Builder withMaxTokens(Integer maxTokens) {
            options.maxTokens = maxTokens;
            return this;
        }

        public Builder withTopK(Integer topK) {
            options.topK = topK;
            return this;
        }

        public Builder withTopP(Float topP) {
            options.topP = topP;
            return this;
        }

        public ChinouAiChatOptions build() {
            return options;
        }
    }
}