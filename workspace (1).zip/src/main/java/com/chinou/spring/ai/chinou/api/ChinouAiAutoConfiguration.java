package com.chinou.spring.ai.chinou.api;

import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.retry.RetryUtils;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.support.RetryTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Auto-configuration for the Chinou AI extension.
 */
@AutoConfiguration
@EnableConfigurationProperties(ChinouAiProperties.class)
@ConditionalOnProperty(prefix = "spring.ai.chinou", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ChinouAiAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    @ConditionalOnMissingBean
    public RetryTemplate chinouAiRetryTemplate(ChinouAiProperties properties) {
        return RetryUtils.createRetryTemplate(
                properties.getRetry().getMaxAttempts(),
                properties.getRetry().getBackoffInitialInterval(),
                properties.getRetry().getBackoffMaxInterval(),
                properties.getRetry().getBackoffMultiplier());
    }

    @Bean
    @ConditionalOnMissingBean(ChinouAiApi.class)
    public ChinouAiApi chinouAiApi(ChinouAiProperties properties,
                                   ObjectMapper objectMapper,
                                   RetryTemplate chinouAiRetryTemplate) {
        properties.validate();
        return new ChinouAiChatClient.DefaultChinouAiApi(properties, objectMapper, chinouAiRetryTemplate);
    }

    @Bean
    @ConditionalOnMissingBean(ChinouAiChatClient.class)
    public ChinouAiChatClient chinouAiChatClient(ChinouAiApi chinouAiApi,
                                                ChinouAiProperties properties,
                                                ObjectMapper objectMapper) {
        return new ChinouAiChatClient(chinouAiApi, properties, objectMapper);
    }

    @Bean
    @ConditionalOnMissingBean(name = "chinouAiChatClient")
    public ChatClient chinouAiChatClientAdapter(ChinouAiChatClient chinouAiChatClient) {
        return chinouAiChatClient;
    }
}