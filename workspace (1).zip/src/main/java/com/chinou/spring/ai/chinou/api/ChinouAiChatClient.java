package com.chinou.spring.ai.chinou.api;

import org.springframework.ai.chat.ChatClient;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.Generation;
import org.springframework.ai.chat.StreamingChatClient;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.MessageType;
import org.springframework.ai.chat.messages.SystemMessage;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.retry.RetryUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.lang.Nullable;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.util.Assert;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Implementation of the ChatClient interface for Chinou AI.
 */
public class ChinouAiChatClient implements ChatClient {

    private final ChinouAiApi chinouAiApi;
    private final ObjectMapper objectMapper;
    private final ChinouAiProperties properties;

    public ChinouAiChatClient(ChinouAiApi chinouAiApi, ChinouAiProperties properties, ObjectMapper objectMapper) {
        Assert.notNull(chinouAiApi, "ChinouAiApi must not be null");
        Assert.notNull(properties, "ChinouAiProperties must not be null");
        Assert.notNull(objectMapper, "ObjectMapper must not be null");
        
        this.chinouAiApi = chinouAiApi;
        this.properties = properties;
        this.objectMapper = objectMapper;
    }

    @Override
    public ChatResponse call(Prompt prompt) {
        ChinouAiChatOptions options = ChinouAiChatOptions.fromProperties(this.properties);
        Map<String, Object> requestOptions = this.getRequestOptions(options);
        
        List<Message> messages = new ArrayList<>(prompt.getMessages());
        ChinouAiChatResponse chatCompletion = this.chinouAiApi.chatCompletion(messages, requestOptions);
        
        List<Generation> generations = List.of(
                new Generation(chatCompletion.getMessage().getContent()));
        
        return new ChatResponse(generations);
    }

    @Override
    public ChatResponse call(Prompt prompt, Map<String, Object> options) {
        ChinouAiChatOptions chatOptions = ChinouAiChatOptions.fromProperties(this.properties);
        
        // Override default options with provided options
        if (options.containsKey("temperature")) {
            chatOptions.setTemperature((Float) options.get("temperature"));
        }
        if (options.containsKey("maxTokens")) {
            chatOptions.setMaxTokens((Integer) options.get("maxTokens"));
        }
        // Add more options as needed
        
        Map<String, Object> requestOptions = this.getRequestOptions(chatOptions);
        
        List<Message> messages = new ArrayList<>(prompt.getMessages());
        ChinouAiChatResponse chatCompletion = this.chinouAiApi.chatCompletion(messages, requestOptions);
        
        List<Generation> generations = List.of(
                new Generation(chatCompletion.getMessage().getContent()));
        
        return new ChatResponse(generations);
    }

    private Map<String, Object> getRequestOptions(ChinouAiChatOptions options) {
        Map<String, Object> requestOptions = new HashMap<>();
        if (options.getTemperature() != null) {
            requestOptions.put("temperature", options.getTemperature());
        }
        if (options.getMaxTokens() != null) {
            requestOptions.put("max_tokens", options.getMaxTokens());
        }
        if (options.getTopK() != null) {
            requestOptions.put("top_k", options.getTopK());
        }
        if (options.getTopP() != null) {
            requestOptions.put("top_p", options.getTopP());
        }
        // Add any other supported options

        return requestOptions;
    }

    /**
     * Default implementation of the ChinouAiApi interface using RestClient.
     */
    static class DefaultChinouAiApi implements ChinouAiApi {

        private final RestClient restClient;
        private final ObjectMapper objectMapper;
        private final ChinouAiProperties properties;
        private final RetryTemplate retryTemplate;

        public DefaultChinouAiApi(ChinouAiProperties properties, ObjectMapper objectMapper, RetryTemplate retryTemplate) {
            Assert.notNull(properties, "ChinouAiProperties must not be null");
            Assert.notNull(properties.getBaseUrl(), "Base URL must not be null");
            Assert.notNull(objectMapper, "ObjectMapper must not be null");
            
            this.properties = properties;
            this.objectMapper = objectMapper;
            this.retryTemplate = retryTemplate;
            
            RestClient.Builder builder = RestClient.builder()
                    .baseUrl(properties.getBaseUrl());
                    
            // Add Basic Authentication
            if (properties.getUsername() != null && properties.getPassword() != null) {
                builder.requestInterceptor(request -> {
                    String auth = properties.getUsername() + ":" + properties.getPassword();
                    byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(StandardCharsets.UTF_8));
                    String authHeader = "Basic " + new String(encodedAuth);
                    request.getHeaders().add(HttpHeaders.AUTHORIZATION, authHeader);
                });
            }
            
            this.restClient = builder.build();
        }

        @Override
        public ChinouAiChatResponse chatCompletion(String prompt, @Nullable Map<String, Object> options) {
            return chatCompletion(List.of(new UserMessage(prompt)), options);
        }

        @Override
        public ChinouAiChatResponse chatCompletion(List<Message> messages, @Nullable Map<String, Object> options) {
            // Create the outer structure of the request body according to Chinou API format
            Map<String, Object> requestBody = new HashMap<>();
            Map<String, Object> llmRequest = new HashMap<>();
            
            // Add sessionId (empty by default)
            llmRequest.put("sessionId", "");
            
            // Set up the LLMDescriptor
            Map<String, Object> llmDescriptor = new HashMap<>();
            llmDescriptor.put("model", properties.getModel());
            
            // Set up model_params with options
            Map<String, Object> modelParams = new HashMap<>();
            modelParams.put("temperature", options != null && options.containsKey("temperature") ? 
                options.get("temperature") : properties.getOptions().getTemperature());
            modelParams.put("top_p", options != null && options.containsKey("top_p") ? 
                options.get("top_p") : properties.getOptions().getTopP());
            modelParams.put("max_tokens", options != null && options.containsKey("max_tokens") ? 
                options.get("max_tokens") : properties.getOptions().getMaxTokens());
            
            llmDescriptor.put("model_params", modelParams);
            llmRequest.put("LLMDescriptor", llmDescriptor);
            
            // Combine all messages into a single body string
            String combinedBody = messages.stream()
                    .map(message -> {
                        String role = "";
                        if (message.getMessageType().equals(MessageType.USER)) {
                            role = "User: ";
                        } else if (message.getMessageType().equals(MessageType.SYSTEM)) {
                            role = "System: ";
                        } else if (message.getMessageType().equals(MessageType.ASSISTANT)) {
                            role = "Assistant: ";
                        }
                        return role + message.getContent();
                    })
                    .collect(Collectors.joining("\n"));
            
            // Set the body field
            llmRequest.put("body", combinedBody);
            
            // Set the protocol
            llmRequest.put("_protocol", "chinou-json:1");
            
            // Add the LLMRequest to the main request body
            requestBody.put("LLMRequest", llmRequest);
            
            try {
                String requestBodyJson = objectMapper.writeValueAsString(requestBody);
                
                return RetryUtils.runWithRetry(() -> {
                    HttpHeaders headers = new HttpHeaders();
                    headers.setContentType(MediaType.APPLICATION_JSON);
                
                    return restClient.post()
                        .uri("/invoke")  // Your API endpoint
                        .body(requestBodyJson)
                        .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                        .retrieve()
                        .body(ChinouAiChatResponse.class);
                }, retryTemplate);
            }
            catch (JsonProcessingException e) {
                throw new RuntimeException("Error serializing request body", e);
            }
        }
        
        private Map<String, String> convertMessage(Message message) {
            Map<String, String> result = new HashMap<>();
            
            if (message.getMessageType().equals(MessageType.USER)) {
                result.put("role", "user");
            }
            else if (message.getMessageType().equals(MessageType.SYSTEM)) {
                result.put("role", "system");
            }
            else if (message.getMessageType().equals(MessageType.ASSISTANT)) {
                result.put("role", "assistant");
            }
            else {
                // Default to user if unknown type
                result.put("role", "user");
            }
            
            result.put("content", message.getContent());
            return result;
        }
    }
}