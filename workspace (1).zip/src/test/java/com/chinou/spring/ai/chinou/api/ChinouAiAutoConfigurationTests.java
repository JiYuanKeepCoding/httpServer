package com.chinou.spring.ai.chinou.api;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.ChatClient;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Tests for {@link ChinouAiAutoConfiguration}.
 */
public class ChinouAiAutoConfigurationTests {

    private final ApplicationContextRunner contextRunner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(ChinouAiAutoConfiguration.class));

    @Test
    public void defaultConfiguration() {
        contextRunner
                .withPropertyValues(
                        "spring.ai.chinou.base-url=https://chinou.com",
                        "spring.ai.chinou.username=testuser",
                        "spring.ai.chinou.password=testpass"
                )
                .run(context -> {
                    assertThat(context).hasSingleBean(ChinouAiApi.class);
                    assertThat(context).hasSingleBean(ChinouAiChatClient.class);
                    assertThat(context).hasSingleBean(ChatClient.class);
                });
    }

    @Test
    public void configurationWithCustomOptions() {
        contextRunner
                .withPropertyValues(
                        "spring.ai.chinou.base-url=https://chinou-custom.com",
                        "spring.ai.chinou.username=testuser",
                        "spring.ai.chinou.password=testpass",
                        "spring.ai.chinou.options.temperature=0.5",
                        "spring.ai.chinou.options.max-tokens=1000",
                        "spring.ai.chinou.options.top-k=20",
                        "spring.ai.chinou.options.top-p=0.8"
                )
                .run(context -> {
                    ChinouAiProperties properties = context.getBean(ChinouAiProperties.class);
                    assertThat(properties.getBaseUrl()).isEqualTo("https://chinou-custom.com");
                    assertThat(properties.getUsername()).isEqualTo("testuser");
                    assertThat(properties.getPassword()).isEqualTo("testpass");
                    assertThat(properties.getOptions().getTemperature()).isEqualTo(0.5f);
                    assertThat(properties.getOptions().getMaxTokens()).isEqualTo(1000);
                    assertThat(properties.getOptions().getTopK()).isEqualTo(20);
                    assertThat(properties.getOptions().getTopP()).isEqualTo(0.8f);
                });
    }

    @Test
    public void configurationWithCustomBeans() {
        contextRunner
                .withPropertyValues(
                        "spring.ai.chinou.base-url=https://chinou.com",
                        "spring.ai.chinou.username=testuser",
                        "spring.ai.chinou.password=testpass"
                )
                .withUserConfiguration(TestConfiguration.class)
                .run(context -> {
                    assertThat(context).hasSingleBean(ChinouAiApi.class);
                    assertThat(context.getBean(ChinouAiApi.class)).isInstanceOf(TestChinouAiApi.class);
                });
    }

    @Test
    public void disabledConfiguration() {
        contextRunner
                .withPropertyValues("spring.ai.chinou.enabled=false")
                .run(context -> {
                    assertThat(context).doesNotHaveBean(ChinouAiApi.class);
                    assertThat(context).doesNotHaveBean(ChinouAiChatClient.class);
                });
    }

    @Configuration
    static class TestConfiguration {

        @Bean
        public ChinouAiApi chinouAiApi() {
            return new TestChinouAiApi();
        }
    }

    static class TestChinouAiApi implements ChinouAiApi {

        @Override
        public ChinouAiChatResponse chatCompletion(String prompt, java.util.Map<String, Object> options) {
            return null;
        }

        @Override
        public ChinouAiChatResponse chatCompletion(java.util.List<org.springframework.ai.chat.messages.Message> messages,
                                                  java.util.Map<String, Object> options) {
            return null;
        }
    }
}