package com.chinou.spring.ai.chinou.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ChinouAiRequestResponseTest {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void testResponseDeserialization() throws Exception {
        // Create a sample JSON response
        String jsonResponse = "{"
                + "\"LLMDocuResponse\": {"
                + "    \"body\": \"Hello! How can I help\","
                + "    \"metrics\": {"
                + "        \"invoke_time\": \"2025-06-19T04:42:45.066451+0000\","
                + "        \"execution_time_ms\": 344.16,"
                + "        \"prompt_len\": 8,"
                + "        \"response_len\": 12"
                + "    },"
                + "    \"parameters\": {"
                + "        \"server\": \"i-xxx:9001\""
                + "    },"
                + "    \"LLMDocumentSet\": {"
                + "        \"documents\": []"
                + "    }"
                + "},"
                + "\"_protocol\": \"chinou-json:1\""
                + "}";

        // Parse the JSON into our response object
        ChinouAiChatResponse response = objectMapper.readValue(jsonResponse, ChinouAiChatResponse.class);

        // Verify the response was parsed correctly
        assertNotNull(response);
        assertNotNull(response.getLlmDocuResponse());
        assertEquals("Hello! How can I help", response.getLlmDocuResponse().getBody());
        assertEquals("chinou-json:1", response.getProtocol());
        assertEquals("i-xxx:9001", response.getModel());
        
        // Verify metrics
        assertNotNull(response.getLlmDocuResponse().getMetrics());
        assertEquals("2025-06-19T04:42:45.066451+0000", response.getLlmDocuResponse().getMetrics().getInvokeTime());
        assertEquals(344.16, response.getLlmDocuResponse().getMetrics().getExecutionTimeMs());
        assertEquals(8, response.getLlmDocuResponse().getMetrics().getPromptLen());
        assertEquals(12, response.getLlmDocuResponse().getMetrics().getResponseLen());
        
        // Verify document set
        assertNotNull(response.getLlmDocuResponse().getLlmDocumentSet());
        assertNotNull(response.getLlmDocuResponse().getLlmDocumentSet().getDocuments());
        assertTrue(response.getLlmDocuResponse().getLlmDocumentSet().getDocuments().isEmpty());
        
        // Test the helper method
        assertEquals("Hello! How can I help", response.getMessage().getContent());
    }
}
