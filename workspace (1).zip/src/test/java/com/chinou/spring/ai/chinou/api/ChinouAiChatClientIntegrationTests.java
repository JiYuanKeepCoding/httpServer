package com.chinou.spring.ai.chinou.api;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ai.chat.ChatResponse;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.chat.messages.Message;
import org.springframework.ai.chat.messages.UserMessage;
import org.springframework.ai.chat.prompt.Prompt;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * Integration tests for {@link ChinouAiChatClient}.
 */
@ExtendWith(MockitoExtension.class)
public class ChinouAiChatClientIntegrationTests {

    @Mock
    private ChinouAiApi chinouAiApi;

    private ChinouAiProperties properties;
    private ChinouAiChatClient chatClient;

    @BeforeEach
    void setup() {
        properties = new ChinouAiProperties();
        properties.setBaseUrl("https://chinou.com");
        properties.setUsername("testuser");
        properties.setPassword("testpass");
        properties.setModel("default-model");

        chatClient = new ChinouAiChatClient(chinouAiApi, properties, new com.fasterxml.jackson.databind.ObjectMapper());
    }

    @Test
    void testSimpleChatCompletion() {
        // Arrange
        String responseContent = "This is a test response from the Chinou AI model.";
        AssistantMessage assistantMessage = new AssistantMessage(responseContent);
        ChinouAiChatResponse apiResponse = new ChinouAiChatResponse(
                assistantMessage, 
                properties.getModel(), 
                new ChinouAiChatResponse.Usage(10, 20, 30)
        );
        
        when(chinouAiApi.chatCompletion(any(List.class), any(Map.class)))
                .thenReturn(apiResponse);

        // Act
        Prompt prompt = new Prompt(new UserMessage("Tell me about Spring AI"));
        ChatResponse response = chatClient.call(prompt);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getResults()).hasSize(1);
        assertThat(response.getResults().get(0).getOutput().getContent()).isEqualTo(responseContent);
    }
    
    @Test
    void testChatCompletionWithOptions() {
        // Arrange
        String responseContent = "This is a test response with custom options.";
        AssistantMessage assistantMessage = new AssistantMessage(responseContent);
        ChinouAiChatResponse apiResponse = new ChinouAiChatResponse(
                assistantMessage, 
                properties.getModel(), 
                new ChinouAiChatResponse.Usage(5, 15, 20)
        );

        when(chinouAiApi.chatCompletion(any(List.class), any(Map.class)))
                .thenReturn(apiResponse);

        // Act
        Prompt prompt = new Prompt(new UserMessage("Tell me a short story"));
        Map<String, Object> options = Map.of(
                "temperature", 0.2f,
                "maxTokens", 500
        );
        ChatResponse response = chatClient.call(prompt, options);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getResults()).hasSize(1);
        assertThat(response.getResults().get(0).getOutput().getContent()).isEqualTo(responseContent);
    }
    
    @Test
    void testMultipleMessages() {
        // Arrange
        String responseContent = "I can help you with Spring AI and your internal model integration.";
        AssistantMessage assistantMessage = new AssistantMessage(responseContent);
        ChinouAiChatResponse apiResponse = new ChinouAiChatResponse(
                assistantMessage, 
                properties.getModel(), 
                new ChinouAiChatResponse.Usage(15, 25, 40)
        );

        when(chinouAiApi.chatCompletion(any(List.class), any(Map.class)))
                .thenReturn(apiResponse);

        // Act
        List<Message> messages = List.of(
                new UserMessage("What is Spring AI?"),
                new AssistantMessage("Spring AI is a framework for AI integration in Spring applications."),
                new UserMessage("How can I integrate my internal model?")
        );
        Prompt prompt = new Prompt(messages);
        ChatResponse response = chatClient.call(prompt);

        // Assert
        assertThat(response).isNotNull();
        assertThat(response.getResults()).hasSize(1);
        assertThat(response.getResults().get(0).getOutput().getContent()).isEqualTo(responseContent);
    }
}