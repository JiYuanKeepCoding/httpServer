import java.util.ArrayList;
import java.util.List;

class LLMDocumentSet {
    private List<Object> documents;
    
    public LLMDocumentSet() {
        this.documents = new ArrayList<>();
    }
    
    public LLMDocumentSet(List<Object> documents) {
        this.documents = documents;
    }
    
    public List<Object> getDocuments() {
        return documents;
    }
    
    public void setDocuments(List<Object> documents) {
        this.documents = documents;
    }
}

class Parameters {
    private String server;
    
    public Parameters() {}
    
    public Parameters(String server) {
        this.server = server;
    }
    
    public String getServer() {
        return server;
    }
    
    public void setServer(String server) {
        this.server = server;
    }
}

class Metrics {
    private String invokeTime;
    private Double executionTimeMs;
    private Integer promptLen;
    private Integer responseLen;
    
    public Metrics() {}
    
    public Metrics(String invokeTime, Double executionTimeMs, Integer promptLen, Integer responseLen) {
        this.invokeTime = invokeTime;
        this.executionTimeMs = executionTimeMs;
        this.promptLen = promptLen;
        this.responseLen = responseLen;
    }
    
    public String getInvokeTime() {
        return invokeTime;
    }
    
    public void setInvokeTime(String invokeTime) {
        this.invokeTime = invokeTime;
    }
    
    public Double getExecutionTimeMs() {
        return executionTimeMs;
    }
    
    public void setExecutionTimeMs(Double executionTimeMs) {
        this.executionTimeMs = executionTimeMs;
    }
    
    public Integer getPromptLen() {
        return promptLen;
    }
    
    public void setPromptLen(Integer promptLen) {
        this.promptLen = promptLen;
    }
    
    public Integer getResponseLen() {
        return responseLen;
    }
    
    public void setResponseLen(Integer responseLen) {
        this.responseLen = responseLen;
    }
}

class LLMDocuResponse {
    private String body;
    private Metrics metrics;
    private Parameters parameters;
    private LLMDocumentSet llmDocumentSet;
    
    public LLMDocuResponse() {}
    
    public LLMDocuResponse(String body, Metrics metrics, Parameters parameters, LLMDocumentSet llmDocumentSet) {
        this.body = body;
        this.metrics = metrics;
        this.parameters = parameters;
        this.llmDocumentSet = llmDocumentSet;
    }
    
    public String getBody() {
        return body;
    }
    
    public void setBody(String body) {
        this.body = body;
    }
    
    public Metrics getMetrics() {
        return metrics;
    }
    
    public void setMetrics(Metrics metrics) {
        this.metrics = metrics;
    }
    
    public Parameters getParameters() {
        return parameters;
    }
    
    public void setParameters(Parameters parameters) {
        this.parameters = parameters;
    }
    
    public LLMDocumentSet getLlmDocumentSet() {
        return llmDocumentSet;
    }
    
    public void setLlmDocumentSet(LLMDocumentSet llmDocumentSet) {
        this.llmDocumentSet = llmDocumentSet;
    }
}

class ChinouAiChatResponse {
    private LLMDocuResponse llmDocuResponse;
    private String protocol;
    
    public ChinouAiChatResponse() {}
    
    public ChinouAiChatResponse(LLMDocuResponse llmDocuResponse, String protocol) {
        this.llmDocuResponse = llmDocuResponse;
        this.protocol = protocol;
    }
    
    public LLMDocuResponse getLlmDocuResponse() {
        return llmDocuResponse;
    }
    
    public void setLlmDocuResponse(LLMDocuResponse llmDocuResponse) {
        this.llmDocuResponse = llmDocuResponse;
    }
    
    public String getProtocol() {
        return protocol;
    }
    
    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }
    
    public String getMessage() {
        if (llmDocuResponse != null && llmDocuResponse.getBody() != null) {
            return llmDocuResponse.getBody();
        }
        return "";
    }
    
    public String getModel() {
        if (llmDocuResponse != null && llmDocuResponse.getParameters() != null) {
            return llmDocuResponse.getParameters().getServer();
        }
        return "unknown";
    }
}

public class TestChinouResponse {
    public static void main(String[] args) {
        // Create a sample response object
        List<Object> documents = new ArrayList<>();
        LLMDocumentSet documentSet = new LLMDocumentSet(documents);
        Parameters parameters = new Parameters("i-xxx:9001");
        Metrics metrics = new Metrics("2025-06-19T04:42:45.066451+0000", 344.16, 8, 12);
        LLMDocuResponse llmDocuResponse = new LLMDocuResponse("Hello! How can I help", metrics, parameters, documentSet);
        ChinouAiChatResponse response = new ChinouAiChatResponse(llmDocuResponse, "chinou-json:1");
        
        // Test the getters
        System.out.println("===== Testing Response Object Structure =====");
        System.out.println("Body: " + response.getLlmDocuResponse().getBody());
        System.out.println("Protocol: " + response.getProtocol());
        System.out.println("Server: " + response.getLlmDocuResponse().getParameters().getServer());
        System.out.println("Invoke Time: " + response.getLlmDocuResponse().getMetrics().getInvokeTime());
        System.out.println("Execution Time: " + response.getLlmDocuResponse().getMetrics().getExecutionTimeMs());
        System.out.println("Prompt Length: " + response.getLlmDocuResponse().getMetrics().getPromptLen());
        System.out.println("Response Length: " + response.getLlmDocuResponse().getMetrics().getResponseLen());
        System.out.println("Document Count: " + response.getLlmDocuResponse().getLlmDocumentSet().getDocuments().size());
        
        // Test helper methods
        System.out.println("\n===== Testing Helper Methods =====");
        System.out.println("getMessage(): " + response.getMessage());
        System.out.println("getModel(): " + response.getModel());
        
        System.out.println("\nAll tests passed! The response structure is correctly implemented.");
    }
}
